var myCarousel = document.querySelector('#imageCarousel');
var carousel = new bootstrap.Carousel(myCarousel, {
  interval: 5000, // Cambia de imagen cada 5 segundos
  pause: false    // No pausa al pasar el mouse
});