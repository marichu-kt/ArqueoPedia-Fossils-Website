/* █░█ █ █▀ ▀█▀ █▀█ █▀█ █ ▄▀█ ░ ░░█ █▀ */
/* █▀█ █ ▄█ ░█░ █▄█ █▀▄ █ █▀█ ▄ █▄█ ▄█ */

// Oculta el banner al hacer clic en el botón de cerrar
document.querySelector('.close-banner').addEventListener('click', function() {
  document.getElementById('banner').style.display = 'none'; // Cambia la propiedad display del banner a 'none'
});
