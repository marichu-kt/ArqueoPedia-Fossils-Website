/* █▄░█ ▄▀█ █░█ █▄▄ ▄▀█ █▀█ ░ ░░█ █▀ */
/* █░▀█ █▀█ ▀▄▀ █▄█ █▀█ █▀▄ ▄ █▄█ ▄█ */

// Alterna la clase "open" en el body para abrir o cerrar el menú
const toggleMenuOpen = () => document.body.classList.toggle("open");
