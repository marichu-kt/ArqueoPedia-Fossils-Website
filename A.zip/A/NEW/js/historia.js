document.querySelector('.close-banner').addEventListener('click', function() {
  document.getElementById('banner').style.display = 'none';
});
