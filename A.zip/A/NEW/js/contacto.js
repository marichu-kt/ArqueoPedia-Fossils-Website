document.getElementById("miFormulario").addEventListener("submit", function (event) {
  const nombre = document.getElementById("nombre");
  const email = document.getElementById("email");
  const telefono = document.getElementById("telefono");
  let formularioValido = true;

  // Restablecer estilos previos
  [nombre, email, telefono].forEach((campo) => {
    campo.style.border = ""; // Restablece el borde
    const mensajeError = campo.nextElementSibling; // Busca un mensaje de error previo
    if (mensajeError) mensajeError.remove(); // Elimina mensajes de error anteriores
  });

  // Validar el nombre
  if (!nombre.value.trim()) {
    mostrarError(nombre, "El nombre no puede estar vacío.");
    formularioValido = false;
  }

  // Validar el correo electrónico
  if (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
    mostrarError(email, "Por favor, ingresa un correo electrónico válido.");
    formularioValido = false;
  }

  // Validar el número de teléfono
  const prefijoEliminado = telefono.value.trim().replace(/^\+\d+\s/, ''); // Elimina el prefijo
  if (!/^\d*$/.test(prefijoEliminado)) {
    mostrarError(telefono, "El teléfono debe contener solo números.");
    formularioValido = false;
  }

  // Detener el envío si hay errores
  if (!formularioValido) {
    event.preventDefault();
  }
});

// Función para mostrar errores con estilo
function mostrarError(campo, mensaje) {
  campo.style.border = "2px solid red"; // Agrega borde rojo al campo
  const mensajeError = document.createElement("span"); // Crea un elemento <span> para el mensaje
  mensajeError.style.color = "red"; // Color del texto en rojo
  mensajeError.style.fontSize = "12px"; // Tamaño de fuente pequeño
  mensajeError.textContent = mensaje; // Mensaje de error
  campo.parentElement.appendChild(mensajeError); // Agrega el mensaje al DOM debajo del campo
}
